package exceptions;
/**
 * This exception is thrown when there is an error related to menu input in the application.
 * It typically indicates invalid input provided by the user when interacting with the application menu.
 * <p>
 * This exception extends the {@code Exception} class.
 * </p>
 * <p>
 * Example usage:
 * <pre>{@code
 *     try {
 *         // Some code that may throw MenuInputException
 *     } catch (MenuInputException e) {
 *         // Handle MenuInputException
 *     }
 * }</pre>
 * </p>
 * @author Group 5
 * @version 1.0
 * @since 2024-03-09
 */
public class MenuInputException extends Exception{
	 /**
     * Constructs a new MenuInputException with the specified detail message.
     * @param message the detail message (which is saved for later retrieval by the {@link #getMessage()} method).
     */
	public MenuInputException(String Message) {
		super(Message);
	}

}
