package model;

/**
 * The Toys class represents an abstract base class for different types of toys.
 * It defines common properties and methods that all toy types may have.
 * <p>
 * Example usage:
 * <pre>{@code
 *     // Cannot directly instantiate Toys class as it is abstract
 *     // Define specific toy classes that extend Toys and implement abstract methods
 * }</pre>
 * </p>
 * <p>
 * This class should be extended by concrete toy classes such as Animals, BoardGames, etc.
 * </p>
 * <p>
 * Note: The methods provided in this class are abstract and must be implemented by subclasses.
 * </p>
 * <p>
 * Note: This class may also include common properties and methods shared by all toys.
 * </p>
 * <p>
 * Note: The methods provided in this class are placeholders and should be implemented accordingly based on the requirements.
 * </p>
 * @author [Group 5]
 * @version 1.0
 * @since 2024-03-09
 */
public abstract class Toys {

    /**
     * Retrieves the name of the toy.
     */
    public abstract void Name();

    /**
     * Retrieves the serial number of the toy.
     */
    public abstract void serialNumber();

    /**
     * Retrieves the brand of the toy.
     */
    public abstract void brand();

    /**
     * Retrieves the price of the toy.
     */
    public abstract void price();

    /**
     * Retrieves the available count of the toy.
     */
    public abstract void availableCount();

    /**
     * Retrieves the age appropriateness of the toy.
     */
    public abstract void ageAppropriate();

    /**
     * Formats the toy data.
     * @return an array of characters representing the formatted toy data.
     */
    public abstract char[] format();

    /**
     * Retrieves the serial number of the toy.
     * @return the serial number of the toy.
     */
    public abstract long getSerialNumber();
}
