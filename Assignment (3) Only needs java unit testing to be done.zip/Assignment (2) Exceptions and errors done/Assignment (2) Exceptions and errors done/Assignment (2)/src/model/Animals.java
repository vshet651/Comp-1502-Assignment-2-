package model;

/**
 * The Animals class represents a type of toy that is an animal.
 * It extends the Toys class and includes additional properties specific to animal toys.
 * <p>
 * Example usage:
 * <pre>{@code
 *     Animals animalToy = new Animals();
 *     animalToy.setName("Elephant");
 *     animalToy.setMaterial("Plush");
 *     animalToy.setSize("Large");
 *     // Set other properties and perform actions as needed
 * }</pre>
 * </p>
 * <p>
 * This class should be further extended and implemented with specific functionalities and properties.
 * </p>
 * @author [Group 5]
 * @version 1.0
 * @since 2024-03-09
 */
public class Animals extends Toys {

    private String Material;
    private String Size;

    /**
     * Retrieves the material of the animal toy.
     * @return the material of the animal toy.
     */
    public String getMaterial() {
        return Material;
    }

    /**
     * Sets the material of the animal toy.
     * @param material the material to be set for the animal toy.
     */
    public void setMaterial(String material) {
        Material = material;
    }

    /**
     * Retrieves the size of the animal toy.
     * @return the size of the animal toy.
     */
    public String getSize() {
        return Size;
    }

    /**
     * Sets the size of the animal toy.
     * @param size the size to be set for the animal toy.
     */
    public void setSize(String size) {
        Size = size;
    }

    // Other methods and properties specific to animal toys can be implemented here

    @Override
    public void Name() {
        // TODO Auto-generated method stub
    }

    @Override
    public void serialNumber() {
        // TODO Auto-generated method stub
    }

    @Override
    public void brand() {
        // TODO Auto-generated method stub
    }

    @Override
    public void price() {
        // TODO Auto-generated method stub
    }

    @Override
    public void availableCount() {
        // TODO Auto-generated method stub
    }

    @Override
    public void ageAppropriate() {
        // TODO Auto-generated method stub
    }

    @Override
    public char[] format() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getSerialNumber() {
        // TODO Auto-generated method stub
        return 0;
    }
}
