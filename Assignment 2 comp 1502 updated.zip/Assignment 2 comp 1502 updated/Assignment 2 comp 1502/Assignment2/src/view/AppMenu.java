package view;

import java.util.Scanner;

public class AppMenu {
	
	Scanner input;
	
	public AppMenu() {
		input = new Scanner(System.in);
	}
	
	public int showMainMenu() {
		System.out.println("*******************************************************\n");
		System.out.println("*          WELCOME TO THE TOY STORY COMPANY!          *\n");
		System.out.println("*******************************************************\n");
		System.out.println("How May We Help You?");
		System.out.println("\t(1)  Search Inventory and Purchase Toy");
		System.out.println("\t(2)  Add New Toy");
		System.out.println("\t(3)  Remove Toy");
		System.out.println("\t(4)  Save & Exit\n");
		System.out.println("Enter Option: ");
		int option = input.nextInt();
		
		input.nextLine(); 
		return option;
	}
	
	public int searchMenu() {
		System.out.println("Find Toys With: ");
		System.out.println("\t(1)  Serial Number(SN)");
		System.out.println("\t(2)  Toy Name");
		System.out.println("\t(3)  Type");
		System.out.println("\t(4)  Back To Main Menu\n");
		System.out.println("Enter Option: ");
		int option = input.nextInt();
		
		input.nextLine();
		return option;
	}
	
	public int promptserialNumber() {
		System.out.println("Enter Serial Number: ");
		int serialNumber = input.nextInt();
		return serialNumber;
	}
	
	public String prompttoyName() {
		System.out.println("Enter Toy Name: ");
		String toyName = input.nextLine().trim().toLowerCase();
		return toyName;
	}
	
	public String promptTypes() {
		System.out.println("Enter Toy Type: ");
		String Type = input.nextLine().trim().toLowerCase();
		return Type;
	}

}
