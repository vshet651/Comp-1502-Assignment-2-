package view;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class AppMenu {

	Scanner input;

	public AppMenu() {
		input = new Scanner(System.in);
	}

	public int showMainMenu() {
		System.out.println("*******************************************************\n");
		System.out.println("*          WELCOME TO THE TOY STORY COMPANY!          *\n");
		System.out.println("*******************************************************\n");
		System.out.println("How May We Help You?");
		System.out.println("\t(1)  Search Inventory and Purchase Toy");
		System.out.println("\t(2)  Add New Toy");
		System.out.println("\t(3)  Remove Toy");
		System.out.println("\t(4)  Save & Exit\n");
		System.out.println("Enter Option: ");
		int option = input.nextInt();

		input.nextLine();
		return option;
	}

	public int searchMenu() {
		System.out.println("Find Toys With: ");
		System.out.println("\t(1)  Serial Number(SN)");
		System.out.println("\t(2)  Toy Name");
		System.out.println("\t(3)  Type");
		System.out.println("\t(4)  Back To Main Menu\n");
		System.out.println("Enter Option: ");
		int option = input.nextInt();

		input.nextLine();
		return option;
	}

	public int promptserialNumber() {
		System.out.println("Enter Serial Number: ");
		int serialNumber = input.nextInt();
		return serialNumber;
	}

	public String prompttoyName() {
		System.out.println("Enter Toy Name: ");
		String toyName = input.nextLine().trim().toLowerCase();
		return toyName;
	}

	public String promptTypes() {
		System.out.println("Enter Toy Type: ");
		String Type = input.nextLine().trim().toLowerCase();
		return Type;
	}

	public void removeToy() {
		System.out.println("Enter Serial Number: ");
		long serialNumberToRemove = input.nextLong();
		input.nextLine();

		boolean found = false;
		Path filePath = Paths.get("res/new_toys.txt");

		try {
			List<String> lines = Files.readAllLines(filePath);
			StringBuilder updatedFileContent = new StringBuilder();

			for (String line : lines) {
				String[] toyInfo = line.split(",");

				long serialNumber = Long.parseLong(toyInfo[0]);

				if (serialNumber == serialNumberToRemove) {
					found = true;
					System.out.println("Toy Found:\n" + "Serial Number:" + toyInfo[0] + ", Toy Name:" + toyInfo[1]
							+ ", Brand:" + toyInfo[2] + ", Price:" + toyInfo[3] + ", Available Count:" + toyInfo[4]
							+ ", Age Appropriate:" + toyInfo[5]);
					System.out.println("Do You Want To Remove Item (Y/N)?: ");
					String confirmation = input.nextLine().trim().toLowerCase();

					if (confirmation.equals("y")) {
						System.out.println("Removing Item...");
						System.out.println("Item Removed!");
						continue;
					} else {
						System.out.println("Item Not Removed.");
					}

				}

				updatedFileContent.append(line).append("\n");

			}

			if (!found) {
				System.out.println("Toy With Serial Number " + serialNumberToRemove + " not Found.");
			}

			Files.write(filePath, updatedFileContent.toString().getBytes());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void addNewToy() {

		System.out.print("Enter Serial Number: ");
		long serialNumber = input.nextLong();
		input.nextLine(); // Consume newline left-over
		System.out.print("Enter Toy Name: ");
		String toyName = input.nextLine();
		System.out.print("Enter Toy Brand: ");
		String toyBrand = input.nextLine();
		System.out.print("Enter Toy Price: ");
		double toyPrice = input.nextDouble();
		System.out.print("Enter Available Counts: ");
		int availableCounts = input.nextInt();
		System.out.print("Enter Appropriate Age: ");
		int appropriateAge = input.nextInt();
		System.out.print("Enter Minimum Number of Players: ");
		int minPlayers = input.nextInt();
		System.out.print("Enter Maximum Number of Players: ");
		int maxPlayers = input.nextInt();
		input.nextLine(); // Consume newline left-over
		System.out.print("Enter Designer Names: ");
		String designerNames = input.nextLine();

		// Display entered values
		System.out.println("\nNew Toy Added!");
		System.out.println("Serial Number: " + serialNumber);
		System.out.println("Toy Name: " + toyName);
		System.out.println("Toy Brand: " + toyBrand);
		System.out.println("Toy Price: " + toyPrice);
		System.out.println("Available Counts: " + availableCounts);
		System.out.println("Appropriate Age: " + appropriateAge);
		System.out.println("Minimum Number of Players: " + minPlayers);
		System.out.println("Maximum Number of Players: " + maxPlayers);
		System.out.println("Designer Names: " + designerNames);

		// Save the toy information to the file
		saveToyToFile(serialNumber, toyName, toyBrand, toyPrice, availableCounts, appropriateAge, minPlayers,
				maxPlayers, designerNames);
	}

	private void saveToyToFile(long serialNumber, String toyName, String toyBrand, double toyPrice, int availableCounts,
			int appropriateAge, int minPlayers, int maxPlayers, String designerNames) {
		try (PrintWriter writer = new PrintWriter(new FileWriter("new_toys.txt"))) {
// Write the toy information to the new file
			writer.println(serialNumber + "," + toyName + "," + toyBrand + "," + toyPrice + "," + availableCounts + ","
					+ appropriateAge + "," + minPlayers + "," + maxPlayers + "," + designerNames);
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
