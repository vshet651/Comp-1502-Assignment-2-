package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import model.ConcreteToy;
import model.Toys;
import view.AppMenu;

public class GameManager {

	private String FILE_PATH = "res/toys.txt";
	private ArrayList<Toys> arrayListToy;
	private AppMenu appMenu;

	public GameManager() throws Exception {
		arrayListToy = new ArrayList<>();
		appMenu = new AppMenu();
		loadData();
		launchApplication();
	}

	private void launchApplication() throws IOException {
		boolean flag = true;

		while (flag) {
			int option = appMenu.showMainMenu();
			switch (option) {
			case 1:
				search();
				break;
			case 2:
				newToy();
				break;
			case 3:
				removeToy();
				break;
			case 4:
				saveAndExit();
				flag = false;
				break;
			}
		}
	}

	private void search() {
		boolean sea = true;

		while (sea) {
			int option = appMenu.searchMenu();
			switch (option) {
			case 1:
				serialNumber();
				break;
			case 2:
				toyName();
				break;
			case 3:
				Type();
				break;
			case 4:
				backToMainMenu();
				break;
			}
		}

	}

	private void backToMainMenu() {
		appMenu.showMainMenu();

	}

	private void newToy() {
		appMenu.addNewToy();
	}

	private void removeToy() {
		appMenu.removeToy();
	}

	private void saveAndExit() throws IOException {
		File toys = new File(FILE_PATH);
		PrintWriter pw = new PrintWriter(toys);

		for (Toys t : arrayListToy) {
			pw.println(t.format());
		}
		pw.close();
		System.out.println("Saving Data Into Database...");
		System.out.println("*********** THANKS FOR VISITING US! ***********");
	}

	private void serialNumber() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Serial Number: ");
		long serialNumber = scanner.nextLong();
		scanner.nextLine();

		boolean found = false;

		for (Toys toy : arrayListToy) {
			if (toy.getSerialNumber() == serialNumber) {
				System.out.println("Toy found:\n" + toy);
				found = true;
				break;
			}
		}

		if (!found) {
			System.out.println("No toy found with Serial number " + serialNumber);
		}

		if (!found) {
			System.out.println("Toy with Serial number " + serialNumber);
		}
	}

	private void toyName() {
		ArrayList<String> arrayListToy = new ArrayList<>();
		ArrayList<String> newArrayListToy = new ArrayList<>();

		// Ask the user to enter the toy name
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the toy name: ");
		String toyName = scanner.nextLine().trim(); // Trim to remove leading/trailing whitespaces

		try {
			// Reading from toys.txt and populating the ArrayList
			BufferedReader reader = new BufferedReader(new FileReader("res/toys.txt"));
			String line;
			while ((line = reader.readLine()) != null) {
				arrayListToy.add(line);
			}
			reader.close();

			// Reading from new_toys.txt and populating the ArrayList
			reader = new BufferedReader(new FileReader("res/new_toys.txt"));
			while ((line = reader.readLine()) != null) {
				newArrayListToy.add(line);
			}
			reader.close();
		} catch (IOException e) {
			System.err.println("Error reading the file: " + e.getMessage());
			return;
		}

		// Outputting details of toys containing the toyName from toys.txt
		boolean found = false;
		for (String toy : arrayListToy) {
			String[] parts = toy.split(";");
			if (parts[1].toLowerCase().contains(toyName.toLowerCase())) {
				System.out.println(toy);
				found = true;
			}
		}

		// Outputting details of toys containing the toyName from new_toys.txt
		for (String toy : newArrayListToy) {
			String[] parts = toy.split(",");
			if (parts[1].toLowerCase().contains(toyName.toLowerCase())) {
				System.out.println(toy);
				found = true;
			}
		}

		// Inform if no toys were found with the given toyName
		if (!found) {
			System.out.println("No toys found with the name '" + toyName + "'.");
		}
	}

	private void Type() {
		// File path
		String filePath = "toys.txt";

		try {
			// Open the file
			FileReader fileReader = new FileReader(filePath);
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			// Read the file line by line
			String line;
			int lineNumber = 1;
			while ((line = bufferedReader.readLine()) != null) {
				// Skip the third line
				if (lineNumber == 3) {
					lineNumber++;
					continue;
				}

				// Print the line
				System.out.println("Line " + lineNumber + ": " + line);
				lineNumber++;
			}

			// Close the file
			bufferedReader.close();

			// Ask the user for a word to search for (excluding 'game')
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter a word to search for (excluding 'game'): ");
			String searchWord = scanner.nextLine();

			// Open the file again to search for the input word
			fileReader = new FileReader(filePath);
			bufferedReader = new BufferedReader(fileReader);

			// Read the file line by line to search for the input word
			lineNumber = 1;
			while ((line = bufferedReader.readLine()) != null) {
				// Skip the third line and lines containing "game"
				if (lineNumber == 3 || line.toLowerCase().contains("game")) {
					lineNumber++;
					continue;
				}

				// If the line contains the input word, print it
				if (line.toLowerCase().contains(searchWord.toLowerCase())) {
					System.out.println("Line " + lineNumber + ": " + line);
				}
				lineNumber++;
			}

			// Close the file
			bufferedReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void loadData() throws Exception {
		File ts = new File(FILE_PATH);
		String currentLine;
		String[] splittedLine;

		if (ts.exists()) {
			Scanner fileReader = new Scanner(ts);

			while (fileReader.hasNextLine()) {

				currentLine = fileReader.nextLine();
				splittedLine = currentLine.split(";");
				Toys t = new ConcreteToy(Long.parseLong(splittedLine[0]), splittedLine[1], splittedLine[2],
						Double.parseDouble(splittedLine[3]), Integer.parseInt(splittedLine[4]),
						Integer.parseInt(splittedLine[5]), splittedLine[6], "");
				arrayListToy.add(t);
			}
			fileReader.close();
		}
	}
}
