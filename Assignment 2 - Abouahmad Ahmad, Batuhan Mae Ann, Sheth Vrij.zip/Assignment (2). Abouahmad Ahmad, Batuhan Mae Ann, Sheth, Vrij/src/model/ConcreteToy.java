package model;
/**
 * The ConcreteToy class represents a specific toy with concrete properties.
 * It extends the Toys class and includes properties such as name, serial number, brand, price, etc.
 * <p>
 * Example usage:
 * <pre>{@code
 *     ConcreteToy toy = new ConcreteToy("ToyName", 123456, "BrandName", 19.99, 10, 8, "Large");
 *     // Set other properties and perform actions as needed
 * }</pre>
 * </p>
 * <p>
 * This class should be further extended and implemented with specific functionalities and properties.
 * </p>
 * <p>
 * Note: The constructors provided in this class are placeholders and should be implemented accordingly based on the requirements.
 * </p>
 * @author [Group 5]
 * @version 1.0
 * @since 2024-03-09
 */
public class ConcreteToy extends Toys{

	private String name;
	private int serialNumber;
	private String brand;
	private double price;
	private int availableCount;
	private int ageAppropriate;
	private String size;
	
	/**
     * Constructs a new ConcreteToy with the specified properties.
     * @param name the name of the toy.
     * @param serialNumber the serial number of the toy.
     * @param brand the brand of the toy.
     * @param price the price of the toy.
     * @param availableCount the available count of the toy.
     * @param ageAppropriate the age appropriateness of the toy.
     * @param size the size of the toy.
     */
	public ConcreteToy(String name, int serialNumber, String brand, double price, int availableCount, int ageAppropriate, String size) {
		this.name = name;
		this.serialNumber = serialNumber;
		this.brand = brand;
		this.price = price;
		this.availableCount = availableCount;
		this.ageAppropriate = ageAppropriate;
		this.size = size;
	}
	
	// Other constructors may be added as needed

    // Getters and setters for the properties

	public ConcreteToy(long l, String string, String string2, double d, int int3, int int4, String string3,
			String string4) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void Name() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void serialNumber() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void brand() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void price() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void availableCount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ageAppropriate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public char[] format() {
		// TODO Auto-generated method stub
		return new char[0];
	}
	
	public void size () {
		
	}

	@Override
	public long getSerialNumber() {
		// TODO Auto-generated method stub
		return 0;
	}
}