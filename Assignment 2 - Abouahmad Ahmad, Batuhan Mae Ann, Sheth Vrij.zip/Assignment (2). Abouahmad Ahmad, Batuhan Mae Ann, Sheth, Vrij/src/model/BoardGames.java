package model;

/**
 * The BoardGames class represents a type of toy that is a board game.
 * It extends the Toys class and includes additional properties specific to board games.
 * <p>
 * Example usage:
 * <pre>{@code
 *     BoardGames boardGame = new BoardGames();
 *     boardGame.setName("Monopoly");
 *     boardGame.setDesigner("Charles Darrow");
 *     boardGame.setAgeAppropriate(8); // Suitable for ages 8 and above
 *     // Set other properties and perform actions as needed
 * }</pre>
 * </p>
 * <p>
 * This class should be further extended and implemented with specific functionalities and properties.
 * </p>
 * @author [Group 5]
 * @version 1.0
 * @since 2024-03-09
 */
public class BoardGames extends Toys {

    private int ageAppropriate;
    private String Designer;

    /**
     * Retrieves the age appropriateness of the board game.
     * @return the age appropriateness of the board game.
     */
    public int getAgeAppropriate() {
        return ageAppropriate;
    }

    /**
     * Sets the age appropriateness of the board game.
     * @param ageAppropriate the age appropriateness to be set for the board game.
     */
    public void setAgeAppropriate(int ageAppropriate) {
        this.ageAppropriate = ageAppropriate;
    }

    /**
     * Retrieves the designer of the board game.
     * @return the designer of the board game.
     */
    public String getDesigner() {
        return Designer;
    }

    /**
     * Sets the designer of the board game.
     * @param designer the designer to be set for the board game.
     */
    public void setDesigner(String designer) {
        Designer = designer;
    }

    // Other methods and properties specific to board games can be implemented here

    @Override
    public void Name() {
        // TODO Auto-generated method stub
    }

    @Override
    public void serialNumber() {
        // TODO Auto-generated method stub
    }

    @Override
    public void brand() {
        // TODO Auto-generated method stub
    }

    @Override
    public void price() {
        // TODO Auto-generated method stub
    }

    @Override
    public void availableCount() {
        // TODO Auto-generated method stub
    }

    @Override
    public void ageAppropriate() {
        // TODO Auto-generated method stub
    }

    @Override
    public char[] format() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getSerialNumber() {
        // TODO Auto-generated method stub
        return 0;
    }
}
