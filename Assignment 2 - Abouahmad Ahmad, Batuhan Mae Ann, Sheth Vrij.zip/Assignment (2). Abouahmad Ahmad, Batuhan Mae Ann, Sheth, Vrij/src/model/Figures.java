package model;

/**
 * The Figures class represents a type of toy that is a figure.
 * It extends the Toys class and includes additional properties specific to figure toys.
 * <p>
 * Example usage:
 * <pre>{@code
 *     Figures figureToy = new Figures();
 *     figureToy.setName("Action Figure");
 *     figureToy.setClassification("Superhero");
 *     // Set other properties and perform actions as needed
 * }</pre>
 * </p>
 * <p>
 * This class should be further extended and implemented with specific functionalities and properties.
 * </p>
 * <p>
 * Note: The methods provided in this class are placeholders and should be implemented accordingly based on the requirements.
 * </p>
 * @author [Group 5]
 * @version 1.0
 * @since 2024-03-09
 */
public class Figures extends Toys {

    private String Classification;

    /**
     * Sets the classification of the figure toy.
     * @param classification the classification to be set for the figure toy.
     */
    public void setClassification(String classification) {
        this.Classification = classification;
    }

    /**
     * Retrieves the classification of the figure toy.
     * @return the classification of the figure toy.
     */
    public String getClassification() {
        return Classification;
    }

    // Other methods and properties specific to figure toys can be implemented here

    @Override
    public void Name() {
        // TODO Auto-generated method stub
    }

    @Override
    public void serialNumber() {
        // TODO Auto-generated method stub
    }

    @Override
    public void brand() {
        // TODO Auto-generated method stub
    }

    @Override
    public void price() {
        // TODO Auto-generated method stub
    }

    @Override
    public void availableCount() {
        // TODO Auto-generated method stub
    }

    @Override
    public void ageAppropriate() {
        // TODO Auto-generated method stub
    }

    @Override
    public char[] format() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getSerialNumber() {
        // TODO Auto-generated method stub
        return 0;
    }
}

