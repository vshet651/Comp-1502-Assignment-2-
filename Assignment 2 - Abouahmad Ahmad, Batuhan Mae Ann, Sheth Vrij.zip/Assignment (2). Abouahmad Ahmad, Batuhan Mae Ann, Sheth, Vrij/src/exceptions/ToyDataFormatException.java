package exceptions;
/**
 * This exception is thrown when there is an error related to the format of toy data in the application.
 * It typically indicates that the format of the data representing a toy is incorrect or incompatible.
 * <p>
 * This exception extends the {@code Exception} class.
 * </p>
 * <p>
 * Example usage:
 * <pre>{@code
 *     try {
 *         // Some code that may throw ToyDataFormatException
 *     } catch (ToyDataFormatException e) {
 *         // Handle ToyDataFormatException
 *     }
 * }</pre>
 * </p>
 * @author [Group 5]
 * @version 1.0
 * @since 2024-03-09
 */
public class ToyDataFormatException extends Exception{
	/**
     * Constructs a new ToyDataFormatException with the specified detail message.
     * @param message the detail message (which is saved for later retrieval by the {@link #getMessage()} method).
     */
	public ToyDataFormatException(String message) {
		super(message);
	}

}
