package application;

import controller.GameManager;
import view.AppMenu;

public class AppDriver {
	/**
	 * This class represents the driver program for the application. It initializes the application menu and the game manager.
	 */
	public static void main(String[] args) throws Exception {

		AppMenu appMenu = new AppMenu();
		GameManager gameManager = new GameManager();
	}

}
