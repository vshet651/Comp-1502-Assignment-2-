package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import exceptions.MenuInputException;
import view.AppMenu;

public class AppMenuTest {

    private AppMenu appMenu;

    @Before
    public void setUp() {
        appMenu = new AppMenu();
    }

    @Test
    public void testShowMainMenu_ValidInput() throws MenuInputException {
        // Arrange
        int expectedOption = 1;
        String input = "1\n"; // Simulate user input

        // Act
        int actualOption = simulateUserInput(input);

        // Assert
        assertEquals(expectedOption, actualOption);
    }

    @Test(expected = MenuInputException.class)
    public void testShowMainMenu_InvalidInput() throws MenuInputException {
        // Arrange
        String input = "invalid\n"; // Simulate invalid user input

        // Act
        simulateUserInput(input); // This should throw MenuInputException
    }

    @Test
    public void testSearchMenu_ValidInput() throws MenuInputException {
        // Arrange
        int expectedOption = 3;
        String input = "3\n"; // Simulate user input

        // Act
        int actualOption = simulateUserInput(input);

        // Assert
        assertEquals(expectedOption, actualOption);
    }

    @Test(expected = MenuInputException.class)
    public void testSearchMenu_InvalidInput() throws MenuInputException {
        // Arrange
        String input = "invalid\n"; // Simulate invalid user input

        // Act
        simulateUserInput(input); // This should throw MenuInputException
    }

    @Test
    public void testPromptSerialNumber_ValidInput() throws MenuInputException {
        // Arrange
        int expectedSerialNumber = 123;
        String input = "123\n"; // Simulate user input

        // Act
        int actualSerialNumber = simulateUserInputForPromptMethods(input);

        // Assert
        assertEquals(expectedSerialNumber, actualSerialNumber);
    }

    @Test(expected = MenuInputException.class)
    public void testPromptSerialNumber_InvalidInput() throws MenuInputException {
        // Arrange
        String input = "invalid\n"; // Simulate invalid user input

        // Act
        simulateUserInputForPromptMethods(input); // This should throw MenuInputException
    }

    // More tests for other methods can be added similarly...

    // Helper method to simulate user input and return the result
    private int simulateUserInput(String input) throws MenuInputException {
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));
        return appMenu.showMainMenu();
    }

    // Helper method to simulate user input for prompt methods and return the result
    private int simulateUserInputForPromptMethods(String input) throws MenuInputException {
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));
        return appMenu.promptserialNumber();
    }
}
