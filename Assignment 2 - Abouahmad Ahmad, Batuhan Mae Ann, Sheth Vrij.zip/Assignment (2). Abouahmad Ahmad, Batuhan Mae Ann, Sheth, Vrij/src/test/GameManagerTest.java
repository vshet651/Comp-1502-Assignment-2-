package test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import controller.GameManager;
import exceptions.ToyDataFormatException;

public class GameManagerTest {

    private GameManager gameManager;

    @Before
    public void setUp() throws Exception {
        gameManager = new GameManager();
    }

    @After
    public void tearDown() throws Exception {
        gameManager = null;
    }

    @Test
    public void testSerialNumber() {
        // Test case when valid serial number is entered
        long serialNumber = 123456;
        System.setIn(new java.io.ByteArrayInputStream(String.valueOf(serialNumber).getBytes()));
        gameManager.serialNumber(); // This method reads from System.in
        // Check whether the output is as expected
        // Here you would need to modify the assertions based on the behavior of your program

        // Test case when invalid serial number is entered
        System.setIn(new java.io.ByteArrayInputStream("invalid_serial_number".getBytes()));
        gameManager.serialNumber(); // This method reads from System.in
        // Check whether the output is as expected
        // Here you would need to modify the assertions based on the behavior of your program
    }

    @Test
    public void testToyName() throws ToyDataFormatException {
        // Test case when valid toy name is entered
        String toyName = "Test Toy";
        System.setIn(new java.io.ByteArrayInputStream(toyName.getBytes()));
        gameManager.toyName(); // This method reads from System.in
        // Check whether the output is as expected
        // Here you would need to modify the assertions based on the behavior of your program

        // Test case when invalid toy name is entered
        System.setIn(new java.io.ByteArrayInputStream("".getBytes()));
        gameManager.toyName(); // This method reads from System.in
        // Check whether the output is as expected
        // Here you would need to modify the assertions based on the behavior of your program
    }

    @Test
    public void testType() throws ToyDataFormatException {
        // Test case when valid toy type is entered
        String toyType = "Test Type";
        System.setIn(new java.io.ByteArrayInputStream(toyType.getBytes()));
        GameManager.Type(); // This method reads from System.in
        // Check whether the output is as expected
        // Here you would need to modify the assertions based on the behavior of your program

        // Test case when invalid toy type is entered
        System.setIn(new java.io.ByteArrayInputStream("".getBytes()));
        GameManager.Type(); // This method reads from System.in
        // Check whether the output is as expected
        // Here you would need to modify the assertions based on the behavior of your program
    }

    // Similarly, write tests for other methods such as backToMainMenu(), newToy(), removeToy(), saveAndExit(), loadData(), and launchApplication()

}
