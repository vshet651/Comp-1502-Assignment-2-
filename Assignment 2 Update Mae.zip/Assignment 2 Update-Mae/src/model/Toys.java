package model;

public abstract class Toys {
	
	public abstract void Name();
	
	public abstract void serialNumber();
	
	public abstract void brand();
	
	public abstract void price();
	
	public abstract void availableCount();
	
	public abstract void ageAppropriate();

	public abstract char[] format();

	public abstract long getSerialNumber();
	
}
