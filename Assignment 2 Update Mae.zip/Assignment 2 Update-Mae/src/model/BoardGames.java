package model;

public class BoardGames extends Toys{
	
	private int ageAppropriate;
	private String Designer;

	@Override
	public void Name() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void serialNumber() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void brand() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void price() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void availableCount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ageAppropriate() {
		// TODO Auto-generated method stub
		
	}

	public int getAgeAppropriate() {
		return ageAppropriate;
	}

	public void setAgeAppropriate(int ageAppropriate) {
		this.ageAppropriate = ageAppropriate;
	}

	public String getDesigner() {
		return Designer;
	}

	public void setDesigner(String designer) {
		Designer = designer;
	}

	@Override
	public char[] format() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getSerialNumber() {
		// TODO Auto-generated method stub
		return 0;
	}
}
