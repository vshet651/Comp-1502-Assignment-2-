package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import model.ConcreteToy;
import model.Toys;
import view.AppMenu;

public class GameManager {
	
	private String FILE_PATH = "res/toys.txt";
	private ArrayList<Toys> arrayListToy;
	private AppMenu appMenu;
	
	public GameManager() throws Exception {
		arrayListToy = new ArrayList<>();
		appMenu = new AppMenu();
		loadData();
		launchApplication();
	}

	private void launchApplication() throws IOException {
		boolean flag = true;
		
		while (flag) {
			int option = appMenu.showMainMenu();
			switch(option) {
				case 1: 
					search();
					break;
				case 2: 
					newToy();
					break;
				case 3:
					removeToy();
					break;
				case 4:
					saveAndExit();
					flag = false;
					break;
			}
		}
	}

	private void search() {
		boolean sea = true;
		
		while (sea) {
			int option = appMenu.searchMenu();
			switch(option) {
			case 1:
				serialNumber();
				break;
			case 2:
				toyName();
				break;
			case 3:
				Type();
				break;
			case 4:
				backToMainMenu();
				break;
			}
		}
		
	}
	

	private void backToMainMenu() {
		appMenu.showMainMenu();
		
	}

	private void newToy() {
		appMenu.addNewToy();
	}
	
	private void removeToy() {
		appMenu.removeToy();
	}
	
	private void saveAndExit() throws IOException {
		File toys = new File(FILE_PATH);
		PrintWriter pw = new PrintWriter(toys);
		
		for (Toys t : arrayListToy) {
			pw.println(t.format());
		}
		pw.close();
		System.out.println("Saving Data Into Database...");
		System.out.println("*********** THANKS FOR VISITING US! ***********");
	}
	
	private void serialNumber() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Serial Number: ");
		long serialNumber = scanner.nextLong();
		scanner.nextLine();
		
		boolean found = false;
		
		for (Toys toy : arrayListToy) {
			if (toy.getSerialNumber() == serialNumber) {
				System.out.println("Toy found:\n" + toy);
				found = true;
				break;
			}
		}
		
		if (!found) {
			System.out.println("Toy with Serial number " + serialNumber);
		}
	}
	
	private void toyName() {
		
	}
	
	private void Type() {
		
	}
	
	private void loadData() throws Exception {
		File ts = new File(FILE_PATH);
		String currentLine;
		String[] splittedLine;
		
		if(ts.exists()) {
			Scanner fileReader = new Scanner(ts);
			
			while(fileReader.hasNextLine()) {
				
				currentLine = fileReader.nextLine();
				splittedLine = currentLine.split(";");
				Toys t = new ConcreteToy(Long.parseLong(splittedLine[0]), splittedLine[1], splittedLine[2], Double.parseDouble(splittedLine[3]), Integer.parseInt(splittedLine[4]), Integer.parseInt(splittedLine[5]), splittedLine[6], "");
				arrayListToy.add(t);
			}
			fileReader.close();
		}
	}
}
