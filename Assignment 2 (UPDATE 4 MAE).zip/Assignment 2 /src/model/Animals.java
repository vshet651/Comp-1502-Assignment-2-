package model;

public class Animals extends Toys{
	
	private String Material;
	private String Size;

	@Override
	public void Name() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void serialNumber() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void brand() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void price() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void availableCount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ageAppropriate() {
		// TODO Auto-generated method stub
		
	}

	public String getMaterial() {
		return Material;
	}

	public void setMaterial(String material) {
		Material = material;
	}

	public String getSize() {
		return Size;
	}

	public void setSize(String size) {
		Size = size;
	}

	@Override
	public char[] format() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getSerialNumber() {
		// TODO Auto-generated method stub
		return 0;
	}

}
