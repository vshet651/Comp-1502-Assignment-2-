package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import model.ConcreteToy;
import model.Toys;
import view.AppMenu;

public class GameManager {
	
	private String FILE_PATH = "res/toys.txt";
	private ArrayList<Toys> arrayListToy;
	private AppMenu appMenu;
	
	public GameManager() throws Exception {
		arrayListToy = new ArrayList<>();
		appMenu = new AppMenu();
		loadData();
		launchApplication();
	}

	private void launchApplication() throws IOException {
		boolean flag = true;
		
		while (flag) {
			int option = appMenu.showMainMenu();
			switch(option) {
				case 1: 
					search();
					break;
				case 2: 
					newToy();
					break;
				case 3:
					removeToy();
					break;
				case 4:
					saveAndExit();
					flag = false;
					break;
			}
		}
	}

	private void search() {
		boolean sea = true;
		
		while (sea) {
			int option = appMenu.searchMenu();
			switch(option) {
			case 1:
				serialNumber();
				break;
			case 2:
				toyName();
				break;
			case 3:
				Type();
				break;
			case 4:
				break;
			}
		}
		
	}
	

	private void newToy() {
		
	}
	
	private void removeToy() {
		
	}
	
	private void saveAndExit() throws IOException {
		File toys = new File(FILE_PATH);
		PrintWriter pw = new PrintWriter(toys);
		
		for (Toys t : arrayListToy) {
			pw.println(t.format());
		}
		pw.close();
		System.out.println("Saving Data Into Database...");
		System.out.println("*********** THANKS FOR VISITING US! ***********");
	}
	
	private void serialNumber() {
		
	}
	
	private void toyName() {
		
	}
	
	private void Type() {
		
	}
	
	private void loadData() throws Exception {
		File ts = new File(FILE_PATH);
		String currentLine;
		String[] splittedLine;
		
		if(ts.exists()) {
			Scanner fileReader = new Scanner(ts);
			
			while(fileReader.hasNextLine()) {
				
				currentLine = fileReader.nextLine();
				splittedLine = currentLine.split(";");
				Toys t = new ConcreteToy(Integer.parseInt(splittedLine[0]), splittedLine[1], splittedLine[2], Integer.parseInt(splittedLine[3]), Integer.parseInt(splittedLine[4]), Integer.parseInt(splittedLine[5]), splittedLine[6], splittedLine[7]);
				arrayListToy.add(t);
			}
			fileReader.close();
		}
	}
}
