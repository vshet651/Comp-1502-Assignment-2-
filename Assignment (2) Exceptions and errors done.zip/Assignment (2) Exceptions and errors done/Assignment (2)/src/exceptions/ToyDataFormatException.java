package exceptions;

public class ToyDataFormatException extends Exception{
	
	public ToyDataFormatException(String message) {
		super(message);
	}

}
