package exceptions;

public class MenuInputException extends Exception{
	
	public MenuInputException(String Message) {
		super(Message);
	}

}
