package model;

public class ConcreteToy extends Toys{

	private String name;
	private int serialNumber;
	private String brand;
	private double price;
	private int availableCount;
	private int ageAppropriate;
	private String size;
	
	public ConcreteToy(String name, int serialNumber, String brand, double price, int availableCount, int ageAppropriate, String size) {
		this.name = name;
		this.serialNumber = serialNumber;
		this.brand = brand;
		this.price = price;
		this.availableCount = availableCount;
		this.ageAppropriate = ageAppropriate;
		this.size = size;
	}
	
	public ConcreteToy(long l, String string, String string2, double d, int int3, int int4, String string3,
			String string4) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void Name() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void serialNumber() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void brand() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void price() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void availableCount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ageAppropriate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public char[] format() {
		// TODO Auto-generated method stub
		return new char[0];
	}
	
	public void size () {
		
	}

	@Override
	public long getSerialNumber() {
		// TODO Auto-generated method stub
		return 0;
	}
}

