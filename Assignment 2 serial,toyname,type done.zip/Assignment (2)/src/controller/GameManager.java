package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import exceptions.MenuInputException;
import exceptions.ToyDataFormatException;
import model.ConcreteToy;
import model.Toys;
import view.AppMenu;
/**
 * The GameManager class manages the overall game application.
 * It handles loading data, launching the application, and controlling the flow of the game.
 */
public class GameManager {

    private String FILE_PATH = "res/toys.txt";
    private ArrayList<Toys> arrayListToy;
    private AppMenu appMenu;
    private static Scanner input; // Scanner variable
    
    /**
     * Constructs a new GameManager object.
     * Initializes the array list of toys, the application menu, and the input scanner.
     * Also loads the existing data and launches the application.
     * @throws MenuInputException 
     * 
     * @throws Exception if an error occurs during initialization or data loading.
     */
    public GameManager() throws ToyDataFormatException, MenuInputException {
        arrayListToy = new ArrayList<>();
        appMenu = new AppMenu();
        input = new Scanner(System.in); // Initialize the Scanner
        try {
			loadData();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			launchApplication();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /**
     * Launches the application and enters into the main menu loop.
     * Displays the main menu and prompts the user to select an option.
     * Depending on the selected option, invokes methods for search, adding a new toy, removing a toy, or saving and exiting the application.
     * Exits the loop and terminates the application if the user chooses to save and exit.
     *
     * @throws IOException If an error occurs during file writing.
     * @throws ToyDataFormatException 
     * @throws MenuInputException 
     */
    private void launchApplication() throws IOException, ToyDataFormatException, MenuInputException {
        boolean flag = true;

        while (flag) {
            int option = appMenu.showMainMenu();
            switch (option) {
                case 1:
                    search();
                    break;
                case 2:
                    newToy();
                    break;
                case 3:
                    removeToy();
                    break;
                case 4:
                    saveAndExit();
                    flag = false;
                    break;
            }
        }
    }
    /**
     * Initiates the search functionality, prompting the user to select a search option from the search menu.
     * Depending on the selected option, invokes methods to search for toys by serial number, toy name, or type.
     * Returns to the main menu if the user chooses to go back.
     * @throws ToyDataFormatException 
     * @throws MenuInputException 
     */
    private void search() throws ToyDataFormatException, MenuInputException {
        boolean sea = true;

        while (sea) {
            int option = appMenu.searchMenu();
            switch (option) {
                case 1:
                    serialNumber();
                    break;
                case 2:
                    toyName();
                    break;
                case 3:
                    Type();
                    break;
                case 4:
                    backToMainMenu();
                    break;
            }
        }
    }
    /**
     * Displays the main menu of the application.
     * @throws MenuInputException 
     */
    private void backToMainMenu() throws MenuInputException {
        appMenu.showMainMenu();
    }
    /**
     * Invokes the method to add a new toy through the application menu.
     * @throws MenuInputException 
     */
    private void newToy() throws MenuInputException {
        appMenu.addNewToy();
    }
    /**
     * Invokes the method to remove a toy through the application menu.
     * @throws MenuInputException 
     */
    private void removeToy() throws MenuInputException {
        appMenu.removeToy();
    }
    /**
     * Saves the current data into a file specified by FILE_PATH and exits the program.
     * If an IOException occurs during file writing, it is thrown.
     *
     * @throws IOException If an error occurs during file writing.
     */
    private void saveAndExit() throws IOException, ToyDataFormatException {
        // Check if the arrayListToy is not empty
        if (!arrayListToy.isEmpty()) {
            // Creating a FileWriter object with append mode enabled
            FileWriter fw = new FileWriter(FILE_PATH, true);
            // Creating a PrintWriter object to write to the file
            PrintWriter pw = new PrintWriter(fw);

            try {
                // Iterating over each Toys object in the arrayListToy
                for (Toys t : arrayListToy) {
                    // Check if the Toys object is not empty
                    if (t != null && !t.toString().isEmpty()) {
                        // Writing the formatted representation of the Toys object to the file
                        pw.println(t.format());
                    }
                }
            } finally {
                // Closing the PrintWriter
                pw.close();
            }

            // Printing a message to indicate that data is being saved into the database
            System.out.println("Saving Data Into Database...");
        } else {
            System.out.println("No data to save. Exiting...");
        }
        // Printing a thank you message
        System.out.println("*********** THANKS FOR VISITING US! ***********");
    }

    /**
     * Searches for a toy with a specified serial number in the list of toys.
     * Prints out the details of the toy if found.
     * If no toy with the specified serial number is found, it notifies the user.
     */
    public void serialNumber() {
        System.out.println("Enter the Serial Number: ");
        long serialNumber;
        try {
            serialNumber = Long.parseLong(input.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid serial number.");
            return;
        }

        boolean found = false;
        int count = 1;

        for (Toys toy : arrayListToy) {
            if (toy.getSerialNumber() == serialNumber) {
                if (!found) {
                    System.out.println("Here are the search results:\n");
                    found = true;
                }
                System.out.println("(" + count + ") " + "Toy found:\n" + toy);
                count++;
            }
        }

        if (!found) {
            System.out.println("No toy found with Serial number " + serialNumber);
        }
    }
    /**
     * Searches for toys containing a specified toy name in both toys.txt and new_toys.txt files.
     * Prints out the search results if found.
     * If no toys with the specified name are found, it notifies the user.
     * @throws ToyDataFormatException 
     */
    private static void toyName() throws ToyDataFormatException {
        ArrayList<String> arrayListToy = new ArrayList<>();

        // Ask the user to enter the toy name
        System.out.print("Enter the toy name: \n");
        String toyName = input.nextLine().trim(); // Trim to remove leading/trailing whitespaces

        try {
            // Reading from toys.txt and populating the ArrayList
            BufferedReader reader = new BufferedReader(new FileReader("res/toys.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                arrayListToy.add(line);
            }
            reader.close();
        } catch (IOException e) {
            throw new ToyDataFormatException("Error reading the file: " + e.getMessage());
        }

        // Outputting details of toys containing the toyName from toys.txt
        boolean found = false;
        int resultCount = 0;
        for (int i = 0; i < arrayListToy.size(); i++) {
            String toy = arrayListToy.get(i);
            String[] parts = toy.split(";");
            if (parts.length > 1 && parts[1].toLowerCase().contains(toyName.toLowerCase())) {
                if (!found) {
                    System.out.println("Here are the search results: " + "\n");
                    found = true;
                }
                System.out.println("(" + (resultCount + 1) + ") " + toy); // Numbering the search results
                resultCount++;
            }
        }

        // Option to go back to the search menu
        if (found) {
            System.out.println("(" + (resultCount + 1) + ") Back to Search Menu");
            resultCount++;
        }

        // Inform if no toys were found with the given toyName
        if (!found) {
            System.out.println("No toys found with the name '" + toyName + "'.");
        } else {
            // Prompt user for option to go back to search menu
            System.out.println("Enter the number corresponding to the toy or '"
                    + resultCount + "' to go back to the search menu.");
            int choice = input.nextInt();
            if (choice == resultCount) {
                // Go back to the search menu
                return;
            } else {
                // Handle selection if necessary
            }
        }
    }
    /**
     * Requests the user to input a toy type and searches for toys matching the type in the toys.txt file.
     * Prints out the search results if found.
     * If no toys with the specified type are found, it notifies the user.
     * @throws ToyDataFormatException 
     */
    private static void Type() throws ToyDataFormatException {
        // Ask the user for the toy type
        System.out.print("Enter Toy Type: \n");
        String toyType = input.nextLine().trim(); // Trim to remove leading/trailing whitespaces

        boolean found = false; // Flag to track if any toys were found
        int resultCount = 0; // Counter for the number of matching results

        try {
            // Read from the toys.txt file and display content
            BufferedReader reader = new BufferedReader(new FileReader("res/toys.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                // Check if the line has enough parts to check index 6 or 7
                if (parts.length > 6 && (parts[6].equalsIgnoreCase(toyType) ||
                        (parts.length > 7 && parts[7].equalsIgnoreCase(toyType)))) {
                    if (!found) {
                        System.out.println("Here are the search results:\n");
                        found = true;
                    }
                    System.out.println("(" + (resultCount + 1) + ") " + line); // Numbering the search results
                    resultCount++;
                }
            }
            reader.close();

            // If no toys were found with the specified type
            if (!found) {
                System.out.println("No toys with such type were found.");
            } else {
                // Prompt user for option to go back to search menu
                System.out.println("Enter the number corresponding to the toy or '"
                        + resultCount + "' to go back to the search menu.");
                int choice = input.nextInt();
                if (choice == resultCount) {
                    // Go back to the search menu
                    return;
                } else {
                    // Handle selection if necessary
                }
            }
        } catch (IOException e) {
            throw new ToyDataFormatException("Error reading the file: " + e.getMessage());
        }
    }
    /**
     * Loads toy information from a file and populates an ArrayList with Toy objects.
     *
     * @throws Exception If an error occurs during file reading or parsing.
     */
    private void loadData() throws ToyDataFormatException {
        File ts = new File(FILE_PATH);
        String currentLine = null;
        String[] splittedLine = null;

        if (ts.exists()) {
            try (Scanner fileReader = new Scanner(ts)) {
                while (fileReader.hasNextLine()) {
                	try {
                		currentLine = fileReader.nextLine();
                        splittedLine = currentLine.split(";");
                	} catch (Exception e) {
                		// Catch and throw from the ToyDataFormatException class
                		throw new ToyDataFormatException("Error reading line: " + currentLine);
                	}
                    if (splittedLine.length >= 7 && !splittedLine[0].isEmpty() && !splittedLine[3].isEmpty() && !splittedLine[4].isEmpty() && !splittedLine[5].isEmpty()) {
                    	Toys t = new ConcreteToy(Long.parseLong(splittedLine[0]), splittedLine[1], splittedLine[2],
                                Double.parseDouble(splittedLine[3]), Integer.parseInt(splittedLine[4]),
                                Integer.parseInt(splittedLine[5]), splittedLine[6], "");
                        arrayListToy.add(t);
                    } else {
                    	// Handle the case where there is an empty field
                    	// Catch and throw from the ToyDataFormatException class
                    	throw new ToyDataFormatException("Error: Empty field in line - " + currentLine);
                    }
                }
            } catch (FileNotFoundException e) {
            	throw new ToyDataFormatException("Error: File Not Found - " + FILE_PATH);
            }
        }
    }
}


