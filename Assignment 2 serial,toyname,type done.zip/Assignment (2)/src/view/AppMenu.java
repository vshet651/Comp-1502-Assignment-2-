package view;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

import exceptions.MenuInputException;

/**
 * The AppMenu class represents the menu interface for the Toy Story Company application.
 * It provides methods to display various menus and gather user input.
 */
public class AppMenu {

    Scanner input;

    /**
     * Constructs a new AppMenu object.
     */
    public AppMenu() {
        input = new Scanner(System.in);
    }

    /**
     * Displays the main menu of the application and prompts the user to choose an option.
     * @return The user's selected option.
     */
    public int showMainMenu() throws MenuInputException {
        System.out.println("*******************************************************\n");
        System.out.println("*          WELCOME TO THE TOY STORY COMPANY!          *\n");
        System.out.println("*******************************************************\n");
        System.out.println("How May We Help You?");
        System.out.println("\t(1)  Search Inventory and Purchase Toy");
        System.out.println("\t(2)  Add New Toy");
        System.out.println("\t(3)  Remove Toy");
        System.out.println("\t(4)  Save & Exit\n");
        System.out.println("Enter Option: ");

        int option;
        while (true) {
            if (input.hasNextInt()) {
                option = input.nextInt();
                if (option >= 1 && option <= 4) {
                    // Consume the newline character
                    input.nextLine();
             
                    break;
                } else {
                    throw new MenuInputException("Wrong input, please enter a number:");
                }
            } else {
                throw new MenuInputException("Wrong input, please enter a number:");
            }
        }
        return option;
    }


    /**
     * Displays the search menu for searching toys and prompts the user to choose an option.
     * @return The user's selected search option.
     */
    public int searchMenu() throws MenuInputException{
        System.out.println("\nFind Toys With: ");
        System.out.println("\t(1)  Serial Number(SN)");
        System.out.println("\t(2)  Toy Name");
        System.out.println("\t(3)  Type");
        System.out.println("\t(4)  Back To Main Menu\n");
        System.out.println("Enter Option: ");
        
        int option;
        while (true) {
            if (input.hasNextInt()) {
                option = input.nextInt();
                if (option >= 1 && option <= 4) {
                    input.nextLine(); // Consume the newline character
                    break;
                } else {
                    throw new MenuInputException("Wrong input, please enter a number between 1 and 4:");
                }
            } else {
                throw new MenuInputException("Wrong input, please enter a number:");
            }
        }
        return option;
    }


    /**
     * Prompts the user to enter a serial number.
     * @return The entered serial number.
     */
    public int promptserialNumber() throws MenuInputException{
        System.out.println("Enter Serial Number: ");
        int serialNumber = input.nextInt();
        if (serialNumber <= 0) {
        	throw new MenuInputException("Invalid serial number. Please enter a positive number.");
        }
        return serialNumber;
    }

    /**
     * Prompts the user to enter a toy name.
     * @return The entered toy name.
     */
    public String prompttoyName() throws MenuInputException{
        System.out.println("Enter Toy Name: ");
        String toyName = input.nextLine().trim().toLowerCase();
        if (toyName.isEmpty()) {
        	throw new MenuInputException("Invalid toy name. Please enter a non-empty name.");
        }
        return toyName;
    }

    /**
     * Prompts the user to enter a toy type.
     * @return The entered toy type.
     */
    public String promptTypes() throws MenuInputException{
        System.out.println("Enter Toy Type: ");
        String Type = input.nextLine().trim().toLowerCase();
        if (Type.isEmpty()) {
        	throw new MenuInputException("Invalid toy type. Please enter a non-empty type.");
        }
        return Type;
    }

    /**
     * Removes a toy from the inventory.
     */

	public void removeToy() throws MenuInputException{
		System.out.println("Enter Serial Number: ");
		String serialNumberInput = input.nextLine().trim();
		
		// Check if the input is empty or not a number
		if (serialNumberInput.isEmpty() || !serialNumberInput.matches("\\d+")) {
			System.out.println("Invalid input. Please enter a valid Serial Number.");
			return;
		}
		
		long serialNumberToRemove = Long.parseLong(serialNumberInput);

		boolean found = false;
		Path filePath = Paths.get("res/toys.txt");

		try {
			List<String> lines = Files.readAllLines(filePath, StandardCharsets.UTF_8);
			StringBuilder updatedFileContent = new StringBuilder();

			for (String line : lines) {
				String[] toyInfo = line.split(";");
				
				if (toyInfo.length >= 1 && !toyInfo[0].isEmpty()) {
					long serialNumber = Long.parseLong(toyInfo[0]);

					if (serialNumber == serialNumberToRemove) {
						found = true;
						System.out.println("Toy Found:\n" + "Serial Number:" + toyInfo[0] + ", Toy Name:" + toyInfo[1]
								+ ", Brand:" + toyInfo[2] + ", Price:" + toyInfo[3] + ", Available Count:" + toyInfo[4]
										+ ", Age Appropriate:" + toyInfo[5]);
						System.out.println("Do You Want To Remove Item (Y/N)?: ");
						String confirmation = input.nextLine().trim().toLowerCase();

						if (confirmation.equals("y")) {
							System.out.println("Removing Item...");
							System.out.println("Item Removed!");
							continue;
						} else {
							throw new MenuInputException("Item Not Removed.");
					}

				}
					
			}

				updatedFileContent.append(line).append("\n");

			}

			if (!found) {
				System.out.println("Toy With Serial Number " + serialNumberToRemove + " not Found.");
			}

			Files.write(filePath, updatedFileContent.toString().getBytes());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

    /**
     * Adds a new toy to the inventory.
     * @throws MenuInputException 
     */
    public void addNewToy() throws MenuInputException {

        System.out.print("Enter Serial Number: ");
        long serialNumber = input.nextLong();
        input.nextLine(); // Consume newline left-over
        System.out.print("Enter Toy Name: ");
        String toyName = input.nextLine();
        System.out.print("Enter Toy Brand: ");
        String toyBrand = input.nextLine();
        System.out.print("Enter Toy Price: ");
        double toyPrice = input.nextDouble();
        System.out.print("Enter Available Counts: ");
        int availableCounts = input.nextInt();
        System.out.print("Enter Appropriate Age: ");
        int appropriateAge = input.nextInt();
        System.out.print("Enter Minimum Number of Players: ");
        int minPlayers = input.nextInt();
        System.out.print("Enter Maximum Number of Players: ");
        int maxPlayers = input.nextInt();
        input.nextLine(); // Consume newline left-over
        System.out.print("Enter Designer Names: ");
        String designerNames = input.nextLine();

        // Display entered values
        System.out.println("\nNew Toy Added!");
        System.out.println("Serial Number: " + serialNumber);
        System.out.println("Toy Name: " + toyName);
        System.out.println("Toy Brand: " + toyBrand);
        System.out.println("Toy Price: " + toyPrice);
        System.out.println("Available Counts: " + availableCounts);
        System.out.println("Appropriate Age: " + appropriateAge);
        System.out.println("Minimum Number of Players: " + minPlayers);
        System.out.println("Maximum Number of Players: " + maxPlayers);
        System.out.println("Designer Names: " + designerNames);

        // Save the toy information to the file
        saveToyToFile(serialNumber, toyName, toyBrand, toyPrice, availableCounts, appropriateAge, minPlayers,
				maxPlayers, designerNames);
	}
    /**
     * Saves information about a toy to a file.
     *
     * @param serialNumber   The serial number of the toy.
     * @param toyName        The name of the toy.
     * @param toyBrand       The brand of the toy.
     * @param toyPrice       The price of the toy.
     * @param availableCounts The number of available toys.
     * @param appropriateAge The appropriate age for the toy.
     * @param minPlayers     The minimum number of players for the toy.
     * @param maxPlayers     The maximum number of players for the toy.
     * @param designerNames  The names of the designers of the toy.
     */
	private void saveToyToFile(long serialNumber, String toyName, String toyBrand, double toyPrice, int availableCounts,
	        int appropriateAge, int minPlayers, int maxPlayers, String designerNames) throws MenuInputException{
	    try (PrintWriter writer = new PrintWriter(new FileWriter("res/toys.txt", true))) {
	        // Append the toy information to the existing file
	        writer.println(serialNumber + ";" + toyName + ";" + toyBrand + ";" + toyPrice + ";" + availableCounts + ";"
	                + appropriateAge + ";" + minPlayers + ";" + maxPlayers + ";" + designerNames);
	        writer.flush();
	        System.out.println("Toy information saved to file.");
	    } catch (IOException e) {
	        throw new MenuInputException("Error writing to file: " + e.getMessage());
	    }
	}


}
