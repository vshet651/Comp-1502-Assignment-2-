package application;

import controller.GameManager;
import view.AppMenu;

public class AppDriver {

	public static void main(String[] args) throws Exception {

		AppMenu appMenu = new AppMenu();
		GameManager gameManager = new GameManager();
	}

}
