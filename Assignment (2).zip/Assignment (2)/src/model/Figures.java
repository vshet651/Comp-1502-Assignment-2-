package model;

public class Figures extends Toys{
	
	private String Classification;
	
	public void setClassification(String Classification) {
		this.Classification = Classification;
	}
	
	public String getClassification() {
		return Classification;
	}

	@Override
	public void Name() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void serialNumber() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void brand() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void price() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void availableCount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ageAppropriate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public char[] format() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getSerialNumber() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}

